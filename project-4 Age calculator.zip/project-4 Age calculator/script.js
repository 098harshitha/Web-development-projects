let age;

document.getElementById("caluclate").onclick = function() {
    age = document.getElementById("number").value;
    console.log(age);
    let month = age*12;
    let week = age*52;
    let days = age*365;

document.getElementById("year").textContent = `year: ${age}`;
document.getElementById("month").textContent = `month: ${month}`;
document.getElementById("week").textContent = `week: ${week}`;
document.getElementById("days").textContent = `days: ${days}`;
};